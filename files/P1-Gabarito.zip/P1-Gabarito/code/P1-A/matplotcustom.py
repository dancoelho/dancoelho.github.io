"""Matplotlib template file
   This file contains a custom preamble 
   for scientific plotting. 
   Have fun!
"""
__version__=1.0
__author__ = """Daniel Coelho (daniel.coelho@mail.mcgill.ca)"""

import os
from numpy import*
from matplotlib.pyplot import*
from matplotlib import rcParams
import matplotlib.font_manager
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
font_path = './Arial.TTF'  # the location of the font file
my_font = fm.FontProperties(fname=font_path)  # get the font based on the font_path
# matplotlib.font_manager._rebuild()

rcParams['font.family'] = 'Arial' #Arial/Times New Roman
rcParams["mathtext.fontset"] = "cm" #cm/stix
rcParams['font.size'] = '16'
# rcParams['font.weight'] = 'heavy'
rcParams['legend.fancybox'] = False
rcParams['legend.loc'] = 'best'
rcParams['legend.numpoints'] = 1
rcParams['legend.edgecolor'] = 'black'
rcParams['legend.fontsize'] = 'xx-small'
rcParams['legend.framealpha'] = None
rcParams['legend.scatterpoints'] = 1  
rcParams['legend.title_fontsize'] = 'small'
rcParams['lines.linewidth'] = 1.5
rcParams['lines.linestyle'] = '-'
rcParams['lines.markersize'] = 6 # None
rcParams['lines.markerfacecolor'] = 'None' # auto/None
rcParams['lines.markeredgecolor'] = 'black'
rcParams['lines.markeredgewidth'] = 1.
rcParams['axes.linewidth'] = 1.
rcParams['axes.labelsize'] = 'large' #large
rcParams['axes.labelweight'] = 'heavy'
rcParams['axes.labelpad'] = 2.5
rcParams['xtick.top'] = True
rcParams['ytick.right'] = True
# rcParams['xtick.labelsize'] = 'large'
# rcParams['ytick.labelsize'] = 'large'
rcParams['xtick.direction'] = 'in'
rcParams['ytick.direction'] = 'in'
rcParams['xtick.major.size'] = 5.
rcParams['ytick.major.size'] = 5.
rcParams['xtick.major.width'] = 1.
rcParams['ytick.major.width'] = 1.
rcParams['xtick.minor.visible'] = True
rcParams['ytick.minor.visible'] = True
rcParams['xtick.minor.size'] = 3.
rcParams['ytick.minor.size'] = 3.
rcParams['xtick.minor.width'] = 1.
rcParams['ytick.minor.width'] = 1.
rcParams['xtick.labelsize'] = 'small'
rcParams['ytick.labelsize'] = 'small'
rcParams['grid.linestyle'] = ':'
rcParams['grid.linewidth'] = 1.
rcParams['grid.color'] = 'black'
rcParams['grid.alpha'] = .25
rcParams['figure.figsize']= (4.6,4) # (4.8,3.6)
rcParams['figure.titlesize']= 'small'
rcParams['figure.subplot.hspace']= 0.25
rcParams['figure.subplot.wspace']= 0.25
rcParams['savefig.format']= 'pdf'
rcParams['savefig.bbox']= 'tight'
rcParams['savefig.pad_inches']= 0.025 # 0.025
rcParams['savefig.transparent']= True
# To know more, run: rcParams.keys()