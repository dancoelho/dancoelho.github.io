# -*- coding: UTF-8 -*-
from numpy import*
from matplotlib.pyplot import*
import matplotcustom

# Solucao analítica:
def analitico(t):
	phi = arctan(1/2.6); # aprox. ~ 0.367
	B = 1/sin(phi);      # aprox. ~ 2.79
	return B*exp(-1.5*t)*sin(2.5*t + phi)

def linear(dt):
	return dt

def quad(dt):
	return 0.1*dt**2

# Dados:
m = 1.;
c = 3.;
k = 8.5;
x0 = 1.; v0 = 5.;
t0 = 0.; tf = 4;
dt = 0.1;
t = arange(t0,tf+dt,dt);
N = len(t);

# Euler explícito (Exp):
x = zeros(N);
v = zeros(N);
x[0] = x0; v[0] = v0;
for n in range(len(t)-1):
	x[n+1] = x[n] + dt*v[n]
	v[n+1] = (1-dt*c/m)*v[n] - dt*(k/m)*x[n]
x_exp = x.copy();
v_exp = v.copy();

# Crank-Nicolson (CN):
dt2 = 0.5*dt;
mult1 = (1 - 0.5*dt*c/m)/(1 + 0.5*dt*c/m)
mult2 = (0.5*dt*k/m)/(1 + 0.5*dt*c/m)
p = 0; ite = 100;
iteracoes = [];
eps = 1e-10;
xn1p = xn = x0;
vn1p = vn = v0;
x = [x0]; v = [v0];
for n in range(len(t)-1):
	p = 0;
	while p <= ite:
		p = p + 1;
		xn1p1 = xn + dt2*(vn1p + vn);
		vn1p1 = mult1*vn - mult2*(xn1p + xn);
		Linfx = abs((xn1p1 - xn1p)/xn1p1);
		Linfv = abs((vn1p1 - vn1p)/vn1p1);
		if Linfx < eps and Linfv < eps:
			iteracoes.append(p);
			x.append(xn1p1);
			v.append(vn1p1);
			xn = xn1p1; vn = vn1p1;
			break
		else:
			xn1p = xn1p1; vn1p = vn1p1;

# Solucao analítica: 
t = arange(t0,tf+dt,dt);
xa = analitico(t);

# Calculo do erro:
L1_exp = (abs(x_exp - xa)).sum()/(abs(xa)).sum();
L1_CN = (abs(x - xa)).sum()/(abs(xa)).sum();

# Salvando o erro: (fazer para os 5 dt's)
savetxt('./Erro_explicito/erro_'+str(dt)+'.csv', [L1_exp], delimiter=',');
savetxt('./Erro_CN/erro_'+str(dt)+'.csv', [L1_CN], delimiter=',');

# Fazer o load do vetor com os L1's:
dts = array([0.00001,0.0001,0.001,0.01,0.1]);
plot_erro_exp = []; plot_erro_CN = [];
for i in range(5):
	Erro_exp = loadtxt('./Erro_explicito/erro_'+str(dts[i])+'.csv', delimiter=',');
	Erro_CN = loadtxt('./Erro_CN/erro_'+str(dts[i])+'.csv', delimiter=',');
	plot_erro_exp.append(Erro_exp);
	plot_erro_CN.append(Erro_CN);

# Plot das soluções:
fig1 = figure()
plot(t,x_exp,'r-',label='numérico-Exp')
plot(t,x,'ko',label='numérico-CN')
plot(t,xa,'k-',label='analítico')
xlabel('$t$')
ylabel('$x,v$')
grid(); legend()
fig1.savefig('EDO.pdf',format='pdf')

# Plot da convergencia:
fig2 = figure()
plot(dts,plot_erro_exp,'r-',label='Euler Explícito')
plot(dts,plot_erro_CN,'b-',label='Crank-Nicolson')
plot(dts,linear(dts),'ks-',
	 label='linear')
plot(dts,quad(dts),'ko-',
	 label='quadrático')
xlabel('$\Delta t$')
ylabel('$L_1$')
xscale('log')
yscale('log')
grid(); legend()
fig2.savefig('convergencia.pdf',format='pdf')