# -*- coding: UTF-8 -*-
from numpy import*
from scipy import sparse
from scipy.sparse.linalg import spsolve
from matplotlib.pyplot import*
import matplotcustom

# Solucao analítica:
def analitico(x):
	# (-F/2)*x**2 + (TL-T0+(F*L**2)/2)*x/L + T0
	# (-F/2)*x**2 + (NL + F*L)*x + T0
	return (-F/2)*x**2 + (NL + F*L)*x + T0

def linear(dx):
	return dx

def quad(dx):
	return 0.1*dx**2

# Dados:
T0 = 0.;
# TL = 1.;
NL = -7.;
F = 20.;
L = 1.; dx = 0.1
x0 = -dx/2;
N = int(L/dx + 2); # L = (N-2)*dx
x = arange(x0,L+dx,dx);
Fvec = -(F*dx**2)*ones(N);
Fvec[0] = T0;		# c.c. Dirichlet em x = 0
# Fvec[N-1] = TL;		# c.c. Dirichlet em x = L
Fvec[N-1] = dx*NL;		# c.c. Neumann em x = L

# Construir a matriz A esparsa (mais rápido):
diag0 = -2*ones(N)                      # vetor da diagonal (principal)
diag1 = 1*ones(N)                       # vetor da sub diagonal
diag2 = 1*ones(N)                       # vetor da super diagonal
diag0[0] = 1; diag0[N-1] = 1;
diag2[1] = 1;                           # modificar para extremidade x = 0
diag1[N-2] = -1;               			# modificar para extremidade x = L
dados = array([diag1,diag0,diag2]);     # array de diagonais da matriz
posicao = array([-1,0,1]);              # posicao das diagonais na matriz
A = sparse.dia_matrix((dados, posicao), # construir a matriz esparsa
	shape=(N,N)).tocsr()
T = spsolve(A,Fvec)                     # resolver o sistema linear

# print(A.toarray())

# Solucao analítica:
Ta = analitico(x);          # utilizada para a convergencia
xa = arange(0,L+0.01,0.01); # vetor com mais pontos para o plot
Taa = analitico(xa);        # solução com mais pontos apenas para o plot

# Calculo do erro:
L1 = (abs(T - Ta)).sum()/(abs(Ta)).sum();

# Salvando o erro: (fazer para os 5 dt's)
savetxt('./Erro/erro_'+str(dx)+'.csv', [L1], delimiter=',');

# Fazer o load do vetor com os L1's:
dxs = array([0.1,0.01,0.001,0.0001]);
plot_erro = [];
for i in range(4):
	Erro = loadtxt('./Erro/erro_'+str(dxs[i])+'.csv', delimiter=',');
	plot_erro.append(Erro);

# # Plot das soluções:
fig1 = figure()
plot(x,T,'bo-',label='numérico',markevery=int(.1/dx))
plot(xa,Taa,'k-',label='analítico')
plot(0,T0,'bx',label='$T\,(x=0)$')
plot(L,analitico(L),'rx',label='$T\,(x=L)$')
xlabel('$x$')
ylabel('$T\,(x)$')
grid(); legend()
fig1.savefig('EDO.pdf',format='pdf')

# # Plot da convergencia:
fig2 = figure()
plot(dxs,plot_erro,'b-',label='MDF')
plot(dxs,linear(dxs),'ks-',
	 label='linear')
plot(dxs,quad(dxs),'ko-',
	 label='quadrático')
xlabel('$\Delta x$')
ylabel('$L_1$')
xscale('log')
yscale('log')
grid(); legend()
fig2.savefig('convergencia.pdf',format='pdf')