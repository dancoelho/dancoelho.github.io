# -*- coding: UTF-8 -*-
from numpy import*
from matplotlib.pyplot import* 
import matplotcustom 

# Solucao analítica:
def analitico(t):
	f = u0*exp(la*t)
	return f

def linear(dt):
	return dt

def quad(dt):
	return dt**2

# Dados:
u0 = 1.; la = -1;
t0 = 0; tf = 5;
dt = .25;
t = arange(t0,tf+dt,dt);

# Euler explícito:
u1 = zeros(len(t));
u1[0] = u0;
for n in range(len(t)-1):
	u1[n+1] = (1 + la*dt)*u1[n];

# Euler implícito:
u2 = zeros(len(t));
u2[0] = u0;
mult2 = 1/(1 - la*dt);
for n in range(len(t)-1):
	u2[n+1] = mult2*u2[n];

# Crank-Nicolson:
u3 = zeros(len(t));
u3[0] = u0; theta = 0.5;
mult3 = (1 + la*dt*(1 - theta))/(1 - la*dt*theta);
for n in range(len(t)-1):
	u3[n+1] = mult3*u3[n];

u = analitico(t)
erro1 = (abs(u1 - u)).sum()/(abs(u)).sum(); print(erro1)
erro2 = (abs(u2 - u)).sum()/(abs(u)).sum(); print(erro2)
erro3 = (abs(u3 - u)).sum()/(abs(u)).sum(); print(erro3)
erro = array([erro1, erro2, erro3])

# Salvar vetor com os erros relativos:
savetxt('erro_'+str(dt)+'.csv', erro, delimiter=',')

# Fazer o load do vetor com os erros relativos:
dts = array([0.00001,0.0001,0.001,0.01,0.1])
explicito = zeros(5)
implicito = zeros(5)
CN = zeros(5)
for j in range(5):
	erro = loadtxt('erro_'+str(dts[j])+'.csv', delimiter=',')
	explicito[j] = erro[0]
	implicito[j] = erro[1]
	CN[j] = erro[2]

# Plot resultado:
fig1 = figure();
plot(t,u,'k',
	 label='analítico');
plot(t,u1,'r',
	 label='explícito');
plot(t,u2,'b',
	 label='implícito');
plot(t,u3,'ko',
	 label='Crank-Nicolson');
xlabel('$t$');
ylabel('$u$');
grid(); legend();
title(r'$\Delta t=0.25$')
# show() # mostra figura
fig1.savefig('EDO.pdf',format='pdf');

# Plot convergencia:
fig2 = figure();
plot(dts,linear(dts),'k',
	 label='linear');
plot(dts,quad(dts),'g',
	 label='quadrático');
plot(dts,explicito,'r^-',
	 label='explícito');
plot(dts,implicito,'b',
	 label='implícito');
plot(dts,CN,'ko-',
	 label='Crank-Nicolson');
xlabel('$\Delta t$')
ylabel('$L_1$')
xscale('log')
yscale('log')
grid(); legend();
# show() # mostra figura
fig2.savefig('convergencia.pdf',format='pdf');