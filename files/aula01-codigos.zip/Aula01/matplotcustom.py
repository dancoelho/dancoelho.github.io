"""	This file contains a custom preamble 
	for scientific plotting. 
	Have fun!
"""
__version__=1.0
__author__ = """Daniel Coelho (daniel.coelho@mail.mcgill.ca)"""

import os
from numpy import*
from matplotlib.pyplot import*
from matplotlib import rcParams
import matplotlib.font_manager
# rcParams['font.family'] = 'Arial'
rcParams['font.size'] = '16'
rcParams['legend.fancybox'] = False
rcParams['legend.loc'] = 'best'
rcParams['legend.numpoints'] = 1
rcParams['legend.edgecolor'] = 'black'
rcParams['legend.fontsize'] = 'small'
rcParams['legend.framealpha'] = None
rcParams['legend.scatterpoints'] = 1
rcParams['lines.linewidth'] = 1.5
rcParams['lines.linestyle'] = '-'
rcParams['lines.markersize'] = 8 # None
rcParams['lines.markerfacecolor'] = 'None' # auto/None
rcParams['lines.markeredgecolor'] = 'black'
rcParams['lines.markeredgewidth'] = 1.
rcParams['axes.linewidth'] = 1.
rcParams['axes.labelpad'] = 2.5
rcParams['xtick.top'] = True
rcParams['ytick.right'] = True
rcParams['xtick.direction'] = 'in'
rcParams['ytick.direction'] = 'in'
rcParams['xtick.minor.visible'] = True
rcParams['ytick.minor.visible'] = True
rcParams['grid.linestyle'] = ':'
rcParams['grid.color'] = 'gray'
rcParams['figure.figsize']= (5.4,4.2)
rcParams['figure.subplot.hspace']= 0.2
rcParams['figure.subplot.wspace']= 0.2
rcParams['savefig.format']= 'pdf'
rcParams['savefig.bbox']= 'tight'
rcParams['savefig.pad_inches']= 0.1
rcParams['savefig.transparent']= True
# To know more, run: rcParams.keys()