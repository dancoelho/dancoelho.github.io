# -*- coding: UTF-8 -*-
# Biblioteca para computacao numerica:
from numpy import*
# Biblioteca para plotagem/graficos:
from matplotlib.pyplot import* 
# Modulo de customizacao dos plots (na pasta):
import matplotcustom 

# Funcao para a solucao analitica:
def polinomio(x):
	return x**4-10*x**2-4*x-1

# Funcao para o lado direito da EDO:
def b(x):
	return 4*x**3-20*x-4

# Funcao linear em h:
def linear(h):
	''' A constante c é apenas para distanciar
		uma curva da outra no plot.
	'''
	c = 10;
	return c*h

# Funcao que resolve o exercicio 1 (Aula 01):
def Exercicio1(h):
	''' Essa funcao retorna a solucao numerica,
		o vetor x (dominio) e o erro relativo 
		calculado com referencia
		na solucao analitica.
	'''
	# Dados:
	x0 = -3.                           # inicio do dominio
	xL = 3.                            # fim do dominio
	L = abs(xL-x0)                     # tamanho do dominio
	N = int(L/h) + 1                   # numero de pontos
	print('h: '+str(h))                # Printar o h da vez:
	x = linspace(x0,xL,N)              # vetor x
	u = zeros(N)                       # vetor u
	analitico = polinomio(x)           # solucao analitica
	u[0] = polinomio(x0)               # condicao inicial
	for i in range(N-1):
		u[i+1] = u[i] + h*b(x[i])
	erro = (abs(u - analitico)).sum()/(abs(analitico)).sum()
	return x,u,erro  # [0],[1],[2]

# Salvar os erros relativos para 5 h's:
hs = array([0.00001,0.0001,0.001,0.01,0.1])
plot_erro = []
for i in range(len(hs)):                         # len(.): tamanho de .
	errodavez = Exercicio1(hs[i])[2]             # [2] é o erro 
	plot_erro.append(errodavez)

# Plotar a solucao numerica vs analitica:
h = 0.01                                         # escolha
Exercicio1 = Exercicio1(h)
x = Exercicio1[0]                                # [0] é o vetor x
numerico = Exercicio1[1]                         # [1] é a solucao numerica
analitico = polinomio(x)                         # solucao analitica

fig1 = figure()
plot(x,polinomio(x),'k',
	 label='analítico')
plot(x,numerico,'ko',
	 label='numérico',
	 markevery=int(.1/h))
xlabel('x')
ylabel('u')
grid(); legend()
# show() # mostra figura
fig1.savefig('Exercicio1-numerico.pdf',format='pdf')


# Plotar o erro em funcao de h:
fig2 = figure()
plot(hs,plot_erro,'k^-',
	 label='erro relativo')
plot(hs,linear(hs),'ks-',
	 label='inclinação linear')
xlabel('h')
ylabel('erro')
xscale('log')
yscale('log')
grid(); legend()
# show() # mostrar figura
fig2.savefig('Exercicio1-erro.pdf',format='pdf')