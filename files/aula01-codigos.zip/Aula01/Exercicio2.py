# -*- coding: UTF-8 -*-
# Biblioteca para computacao numerica:
from numpy import*
# Biblioteca para plotagem/graficos:
from matplotlib.pyplot import* 
# Biblioteca/Modulo/funcao para matrizes esparsas:
from scipy import sparse
from scipy.sparse.linalg import spsolve
# Modulo de customizacao dos plots (na pasta):
import matplotcustom 

# Dados:
h = 0.01                           # escolha
x0 = -3.                           # inicio do dominio
xL = 3.                            # fim do dominio
L = abs(xL-x0)                     # tamanho do dominio
N = int(L/h) + 1                   # numero de pontos
print('h: '+str(h))                # Printar o h da vez:
x = linspace(x0,xL,N)              # vetor x
u = zeros(N)                       # vetor u

# Funcao para a solucao analitica:
def polinomio(x):
	return x**4-10*x**2-4*x-1
analitico = polinomio(x)           # solucao analitica

# Funcao para o lado direito da EDO:
def b(x):
	return 4*x**3-20*x-4
b = h*b(x)
b[0] = polinomio(x0)               # condicao de contorno

# # Construir a matriz A (mais lento):
# A = zeros((N,N))
# for i in range(N):
# 	for j in range(N):
# 		if i==j:
# 			A[i,j] = 1
# 			A[i,j-1] = -1
# A[0,-1] = 0
# u = linalg.solve(A,b)              # resolver o sistema linear

# Construir a matriz A esparsa (mais rápido):
diag0 = 1*np.ones(N)                     # vetor da diagonal (principal)
diag1 = -1*np.ones(N)                    # vetor da subdiagonal 
dados = np.array([diag0,diag1]);         # array de diagonais da matriz
posicao = np.array([0,-1]);              # posicao das diagonais na matriz
A = sparse.dia_matrix((dados, posicao),  # construir a matriz esparsa
	shape=(N,N)).tocsr()
u = spsolve(A,b)                         # resolver o sistema linear

# Plotar a solucao numerica vs analitica:
fig1 = figure()
plot(x,analitico,'k',
	 label='analítico')
plot(x,u,'ko',
	 label='numérico',
	 markevery=int(.1/h))
xlabel('x')
ylabel('u')
grid(); legend()
# show() # mostra figura
fig1.savefig('Exercicio2-numerico.pdf',format='pdf')